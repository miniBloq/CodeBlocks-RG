/*
 * react.cpp
 *
 * A program to measure user reaction times.
 *
 * Displays the fractions of seconds between appearance of a
 * a screen prompt and the user pressing a key.
 *
 * Uses a Stopwatch object.
 *
 * @version 1.0 - 18/12/2005
 * @author  jlk
 */

#include <iostream>
#include <winbgim.h>

#include "Stopwatch.h"

using namespace std;

// Function prototypes
void randomBigGO(void);
void flushKeyBuffer(void);
int randInt(int min, int max);
void showTime( double time);
void outdoublexy(int x, int y, double value);


int main(void)
{
    
    Stopwatch watch;
    double reactTime;
    
    // Seed the random number generator (Make GO display truly random)
    srand( time(NULL) );    
    
    // Initialise a small graphics window. Set a white
    // background and black text colour.
    initwindow(320, 240, "React", 400, 300);
    setbkcolor(WHITE);
    setcolor(BLACK);
    delay(4); // necessary with some graphics cards
    cleardevice();
   
    // Display usage message
    outtextxy(5, 20, "Measure your reaction time:");
    delay(4);
    outtextxy(5, 40, "Hit a key at the word 'GO!'");
   
    // Display GO! after a random wait (< 30 seconds)
    // Start the stopwatch
    randomBigGO();
    watch.start();
   
    // Wait until a key is pressed
    while(!kbhit())
        delay(2);
    
    // Get elapsed time from stopwatch
    reactTime = watch.getElapsedTime();
    flushKeyBuffer(); // Remove key from the keyboard buffer


    // Print reaction time
    showTime(reactTime);

    // Wait for any key press then exit
    getch();

    return 0;
}

// Flush the keyboard buffer
void flushKeyBuffer(void)
{
   while(kbhit())
        getch();
}           

// Display GO! after a random wait (1 second < wait < 20 seconds)   
void randomBigGO()
{
    // Set large text and bright colour
    settextstyle(BOLD_FONT, HORIZ_DIR, 10);
    setcolor(CYAN);
    // Wait between 1000 and 20000 milliseconds
    delay(randInt(1000, 20000));
    
    cleardevice();
    outtextxy(60, 25, "GO!");
}    

/*
 * Display the reaction time  
 * Crack a joke if user pressed a key before GO!
 */
void showTime( double time)
{
    // Set normal sized black text
    settextstyle(SIMPLEX_FONT, HORIZ_DIR, 2);
    setcolor(BLACK);    
    delay(4); // Necessary with some video cards    
   
    if(time < 0.01) // Then user pressed before GO!
    {
        outtextxy(15, 140, "Key hit before GO!..");
        outtextxy(15, 175, "- a bundle of nerves,");
        outtextxy(15, 200, "  aren't we?!");
    }
    else
    {
        // Print the time
        outtextxy(20, 150, "Reaction time:");    
        setcolor(RED);    
        delay(4); // Necessary with some video cards    
        outdoublexy(75, 180, time);
        delay(4);
        outtextxy(155, 180, "seconds");
    }
}    

/*
 * Print a double at location x, y
 */
void outdoublexy(int x, int y, double value)
{
    char str[128]; // String to write
    sprintf(str, "%.3f", value); // Convert double to string
    outtextxy(x, y, str); // write string
}

  
/*
 * Return a random integer between min and max
 */
int randInt(int min, int max)
{
    return rand() % (max - min + 1) + min;
}
    

