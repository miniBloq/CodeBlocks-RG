/**
 * Stopwatch.h
 *
 * Stopwatch class header
 * A stopwatch can start, and tell the time elapsed since start.
 *
 * @version 1.0 - 18/12/2005
 * @author jlk
 */
#ifndef STOPWATCH_H
#define STOPWATCH_H 
 
#include <ctime>

class Stopwatch
{
public:

    /**
     * Constructor 
     * Initialises startTicks to 0
     */
     Stopwatch();
     
    /**
     * Start counting time
     */
    void start(void);
    
    /** 
     * Stop counting time and report elapsed time in
     * seconds and decimal parts of seconds since start.
     *
     * @return number of seconds since start, or 0 if 
     * watch not started.
     */
    double getElapsedTime(void);
    
private:
    // Store number of system clock ticks at start of watch
    clock_t startTicks; 
};

#endif

