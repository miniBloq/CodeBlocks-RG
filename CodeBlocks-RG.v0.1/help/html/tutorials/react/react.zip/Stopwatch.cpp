/*
 * Stopwatch.cpp
 *
 * Implements the Stopwatch class
 *
 * @version 1.0 - 18/12/2005
 * @author  jlk
 */
#include "Stopwatch.h"


/*
 * Constructor 
 * Initialises startTicks to 0
 */
Stopwatch::Stopwatch()
{
    startTicks = 0;
}

/*
 * Start counting time
 */
void Stopwatch::start()
{
    // Use clock() system call to obtain number of clock ticks
    // since the start of the program
    startTicks = clock(); //store number of clock ticks at start
}

/*
 * Report elapsed time in seconds and decimal parts of seconds
 * since start.
 *
 * @return number of seconds since start, or 0 if watch not started.
 */
double Stopwatch::getElapsedTime()
{
    if(!startTicks) // Then object was not started
        return 0;
    
    // clock(), and CLOCKS_PER_SEC are defined in header <ctime>     
    return static_cast<double>(clock() - startTicks) / CLOCKS_PER_SEC;
}

