/**
 * Shape is an abstract base class
 *
 * A Shape instance may be filled or not, it has a drawing colour.
 * A Shape object has a width and height and centre coordinates x and y.
 *
 * The base class has an abstract draw() member function that must be
 * implemented by the derived classes.
 *
 * It has a virtual destructor in order to support polymorphism.
 *
 */
#ifndef SHAPE_H
#define SHAPE_H

#include <graphics.h>

namespace twoD
{
    class Shape
    {
    public:
        /**
         * The constructor is inline and provides some default parameter values.
         * @param cntrX int: X coordinate of the center
         * @param cntrY int: Y coordinate of the center
         * @param wdth int: the width of the shape (in X)
         * @param hght int: the height of the shape (in Y)
         * @param clr int: the shape colour
         * @param filled bool: The shape will be drawn filled when true
         */
        inline Shape( int cntrX, int cntrY, int wdth, int hght,
                      int clr = WHITE, bool flld = false)
        : centerX(cntrX), centerY(cntrY), width(wdth), height(hght),
          color(clr), filled(flld){}

        /**
         * Default constructor (Necesary because we have a non default one)
         */
        inline Shape(){}

        /**
         * Destructor must be virtual to support inheritance
         */
        virtual ~Shape() {}

        /////////////////// Accessor member functions

        inline int getColour() const { return color; }

        inline bool isFilled() const { return filled; }

        inline void getCenter(int &cntrX, int &cntrY) const
                    { cntrX = centerX; cntrY = centerY; }

        inline void getDimensions(int &wdth, int &hght) const
                    { wdth = width; hght = height; }

        ////////////////// Modifier member functions

        inline void setColour(int clr) { color = clr; }

        inline void setFilled(bool flld) { filled = flld; }

        inline void setCenter(int cntrX, int cntrY)
                    { centerX = cntrX; centerY =  cntrY; }

        inline void setDimensions(int wdth, int hght)
                    { width = wdth; height = hght; }

        ///////////////////////////////////////////////

        /**
         * Draw is abstract. It must be implemented by derived classes.
         */
        virtual void draw() = 0;

    protected:
        int centerX, centerY;
        int width, height;
        int color;
        bool filled;
    };
} // End namespace twoD
#endif

