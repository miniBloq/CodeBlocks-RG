/**
 * A box is a rectangle with horizontal and vertical sides
 * The Box class derives from the Shape base class
 *
 * Implements the draw member function
 *
 */
#ifndef BOX_H
#define BOX_H

#include "shape.h"

namespace twoD
{
    class Box : public Shape
    {
    public:
        /**
         * The constructor is inline and provides some default parameter values.
         * @param cntrX int: X coordinate of the center
         * @param cntrY int: Y coordinate of the center
         * @param wdth int: the width of the box (in X)
         * @param hght int: the height of the box (in Y)
         * @param clr int: the box colour
         * @param filled bool: The box will be drawn filled when true
         */
        inline Box( int cntrX, int cntrY, int wdth, int hght,
                      int clr = WHITE, bool flld = false)
        : Shape(cntrX, cntrY, wdth, hght, clr, flld) {}

        /**
         * Draw is virtual as it may be re-implemented in derived classes.
         */
        virtual void draw();

    private:
    };
} // End namespace twoD
#endif

