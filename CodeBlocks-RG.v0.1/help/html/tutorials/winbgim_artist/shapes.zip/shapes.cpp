/** Shapes application driver
 *
 * Exercise your artistic flair by creating colourful screens
 *
 * The code demonstrates the use of class inheritance and dynamic collections (vector)
 *
 * - A variety of shapes are created and displayed one by one by pressing
 *   different keys. Once created each shape is stored into a collection (a vector).
 * - All shapes in the collection at any time can be drawn sequentially (on top of each other).
 * - The vector can be emptied and all shapes wiped off the screen.
 *
 * @author jlk
 * Licence: public domain
 **/

#include <vector>
#include <string>

#include "Circle.h"
#include "Box.h"
#include "Ellipse.h"

using namespace std;
using namespace twoD;

// Application constants (window dimensions)
const int WIN_WIDTH  = 800;
const int WIN_HEIGHT = 600;
const int PROMPT_HEIGHT = 30;


// Function prototypes
void initApplication();
void getRandomValues(int &xPos, int &yPos, int &length, int &width,
                     int &color, bool &filled);
void drawShapes(const vector<Shape *> &shapes);
void clearShapes(vector<Shape *> &shapes);

///////////
int main()
{
    Shape *theShape = 0;     // Current shape
    vector<Shape *> shapes;  // Collection of stored shapes

    // Store data describing each new shape
    int xPos, yPos, length, width;
    bool filled;
    int color;

    initApplication(); // Start up the window.

    // Obtain a character representing a choice of action 
    char choice = toupper(getch());
	
    while (choice != 'Q') // and execute choice in a loop until the user quits
    {
        // Obtain random shape values automatically
        getRandomValues(xPos, yPos, length, width, color, filled);

        switch(choice)
        {
        case 'B': // Create a Box object ( an instance of class Box)
            theShape = new Box(xPos, yPos, length, width, color, filled );
        break;
        case 'E': // Create Ellipse object
            theShape = new twoD::Ellipse(xPos, yPos, length, width,
                                         color, filled);
        break;
        case 'C': // Create instance of Circle class
            theShape = new Circle(xPos, yPos, length / 2, color, filled);
        break;
        case 'D': // Draw all shapes currently stored in vector
            drawShapes(shapes);
            theShape = 0; // indicates no new shape
        break;
        case 'W': // Delete list of shapes stored in vector
            clearShapes(shapes);
            theShape = 0; // no new shape
        break;
        default :
            theShape = 0; // no new shape
        break;
        }
        if(theShape != 0) // if we have a new shape
        {
            clearviewport();            // Erase the screen
            theShape->draw();           // Show only the new shape
            shapes.push_back(theShape); // Add the new shape to the collection
        }

        choice = toupper(getch()); // Get new choice and loop again
    }
	
    return 0;
}

/*
 * Draw the list of all shapes currently in the vector
 */
void drawShapes(const vector<Shape *> &shapes)
{
    int numShapes = shapes.size();

    clearviewport();
    for(int i = 0; i < numShapes; i++)
        shapes[i]->draw();
}

/*
 * Delete the collection of shapes stored into the vector
 */
void clearShapes(vector<Shape *> &shapes)
{
    int numShapes = shapes.size();
    clearviewport();

    // Release all shape memory previously allocated for each shape
    for(int i = 0; i < numShapes; i++)
        delete shapes[i];

    shapes.clear(); // empty the vector
}

/*
 * Initialise the application: Open window, print prompt, randomize
 */
void initApplication()
{
	// Program menu bar. Convert from const strin to char *
	char *menu = const_cast<char *>
	("| [B]ox | | [C]ircle | | [E]llipse | | [D]raw Shapes | | [W]ipe Shapes | | [Q]uit |");

    srand(time(NULL)); // initialize the random number generator

    initwindow(WIN_WIDTH, WIN_HEIGHT, "2D Shapes");
    delay(50); // Startup fails on some fast PCs otherwise

    // Print the prompt
    settextstyle(EUROPEAN_FONT, HORIZ_DIR, 1);
    outtextxy(20, 4, menu);

    // Set viewport not to draw over the prompt
    setviewport(0, PROMPT_HEIGHT, getmaxx(), getmaxy(), true);
}

/*
 * Return a random integer between min and max
 */
int randInt(int min, int max)
{
    return rand() % (max - min + 1) + min;
}

/*
 * Use random numbers to generate the various shape values
 */
void getRandomValues(int &xPos, int &yPos, int &length, int &width,
                     int &color, bool &filled)
{
    xPos = randInt(0, WIN_WIDTH);
    yPos = randInt(PROMPT_HEIGHT, WIN_HEIGHT);
    length = randInt(30, WIN_WIDTH / 3);
    width = randInt(30, WIN_WIDTH / 3);
    filled = randInt(0, 1);
    color = randInt(1, 15);
}

