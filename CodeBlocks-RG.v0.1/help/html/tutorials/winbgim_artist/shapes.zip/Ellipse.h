/**
 * The Ellipse class derives from the Shape base class
 *
 * Implements the draw member function
 *
 * @author jlk
 * Licence: public domain
 */

#ifndef ELLIPSE_H
#define ELLIPSE_H

#include "shape.h"

namespace twoD
{
    class Ellipse: public Shape
    {
    public:

        /**
         * The constructor is inline and provides some default parameter values.
         * @param cntrX int: X coordinate of the center
         * @param cntrY int: Y coordinate of the center
         * @param horzAxis int: Length of the horizontal axis
         * @param vertAxis int: Length of the vertical axis
         * @param clr int: the shape colour
         * @param filled bool: The ellipse will be drawn filled when true
         */
        inline Ellipse( int cntrX, int cntrY, int horzAxis, int vertAxis,
                        int clr = WHITE, bool flld = false)
        : Shape(cntrX, cntrY, horzAxis, vertAxis, clr, flld) {}

        /**
         * Draw is virtual as it may be re-implemented in derived classes.
         */
        virtual void draw() const;

    private:
    };
} // End namespace twoD
#endif

