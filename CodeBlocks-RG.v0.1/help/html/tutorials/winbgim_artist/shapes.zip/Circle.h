/**
 * The Circle class derives from the Ellipse, that itself derives from Shape
 *
 * A circle is an ellipse with same lengths for both axes
 * Re-uses the ellipse draw function
 *
 * @author jlk
 * Licence: public domain
 */
#ifndef CIRCLE_H
#define CIRCLE_H

#include "Ellipse.h"

namespace twoD
{
    class Circle : public Ellipse
    {
    public:
    
        /**
         * The constructor is inline and provides some default parameter values.
         * @param cntrX int: X coordinate of the center
         * @param cntrY int: Y coordinate of the center
         * @param radius int: Length of the circle radius
         * @param clr int: the circle colour
         * @param filled bool: The circle will be drawn filled when true
         */
        inline Circle( int cntrX, int cntrY, int radius,
                      int clr = WHITE, bool flld = false)
        :Ellipse(cntrX, cntrY, radius * 2, radius * 2, clr, flld) {}
    
    private:
    };
}

#endif

