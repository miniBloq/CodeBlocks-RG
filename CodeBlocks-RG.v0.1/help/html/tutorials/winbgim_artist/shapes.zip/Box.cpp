/**
 * A box is a rectangle with vertical and horizontal sides
 * The Box class derives (inherits) from the Shape class
 *
 * Implements the draw member function
 *
 *
 * @author jlk
 * Licence: public domain
 */
#include "Box.h"

namespace twoD
{
    /*
     * Draw is virtual as it may be re-implemented in derived classes.
     */
    void Box::draw() const
    {
        // if filled, draw with fillpoly function
        if(filled)
        {
            int poly[8];
            setfillstyle(SOLID_FILL, color);
            poly[0] = centerX - width / 2;
            poly[1] = centerY - height / 2;
            poly[2] = centerX + (width + 1) / 2;
            poly[3] = centerY - height / 2;
            poly[4] = centerX + (width + 1) / 2;
            poly[5] = centerY + (height + 1) / 2;
            poly[6] = centerX - width / 2;
            poly[7] = centerY + (height + 1) / 2;
            fillpoly(4, poly);
        }
        else // if not, draw with rectangle function
        {
            setcolor(color);
            rectangle( centerX - width / 2, centerY - height / 2,
                       centerX + (width + 1) / 2, centerY + (height + 1) / 2);
        }
    }
} // end namespace twoD

