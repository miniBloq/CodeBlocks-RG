/**
 * An Ellipse may be filled or not
 * The Ellipse class derives from the Shape class
 *
 * Implements the draw member function
 *
 * @author jlk
 * Licence: public domain
 */
#include "Ellipse.h"

namespace twoD
{
    /*
     * Draw is virtual as it may be re-implemented in derived classes.
     */
    void Ellipse::draw() const
    {
        // if filled, draw with fillellipse
        if(filled)
        {
            setfillstyle(SOLID_FILL, color);
            fillellipse(centerX, centerY, width, height);
        }
        else // if not, draw with ellipse function
        {
            setcolor(color);
            ellipse(centerX, centerY, 0, 360, width, height);
        }
    }
} // End namespace twoD

