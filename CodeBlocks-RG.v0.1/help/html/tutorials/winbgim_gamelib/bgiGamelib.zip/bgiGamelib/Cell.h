/**
 * Cell.h
 *
 * Declares a Cell class. 
 * A Cell is a rectangular coloured area and optional central tile (image).
 *
 * @author jlk
 * @version 1.0 - August 2005
 * @licence Public Domain
 */
#ifndef CELL_H
#define CELL_H

/**
 * Class Cell.
 * A cell is the basic constituent of a graphic grid.
 * A cell has a colour and optionally a tile (image drawn on the cell)
 * 
 * @author  jlk
 * @version 1.0 30/08/05
 */
#include <iostream>
#include <graphics.h>

#include "ImageBuffer.h"

class Cell
{    
public:
   /** Construct a Cell instance.
     *  
     * @param color -background colour of cell
     * @param fillMode -One of the WinBGIm fill modes
     * @param tile -ImageBuffer. If given will be drawn on the tile.
     */
    Cell( int color = BLACK, int fillMode = SOLID_FILL, ImageBuffer *tile = 0);

    /**
     * Usually called by the grid setup member function
     * It allows the cell to set itself up depending on grid location.
     *
     * @param leftX -int, x coordinate of the left edge of the cell
     * @param topY  -int, y coordinate of the top edge of the cell
     */
    void setup(int leftX, int topY);
    
    /**
     * Usually called by the grid read() member function
     * the cell can read its own data from stream.
     *
     * @param inputFile -istream reference, an open input file
     *
     * @return reference to the input stream
     */
    // 
    std::istream &read(std::istream &inputFile);
     
    /**
     * Draw the cell (border, fill colour, and tile if given)
     *
     * @param leftX -int, x window coordinate of the left edge of the cell
     * @param topY  -int, y window coordinate of the  top edge of the cell
     * @param mode -int, WinBGIm drawing mode
     */
    void draw(int leftX, int topY, int mode = COPY_PUT);
    
    // Set the Cell tile
    inline void setTile(ImageBuffer *img){tile = img;} 
    
    // Set the cell color and fill mode
    inline void setFill(int clr, int fillStyle = SOLID_FILL)
    {   color = clr; fillMode = fillStyle; }

    /* Static class function to access class-wide variables */
    // Return the cell width
    inline static int getWidth(){ return width; }

    // Set the cell width
    inline static void setWidth(int wdth){ width = wdth; }
            
    // Return the cell height
    inline static int getHeight(){ return height; }

    // Set the cell height
    inline static void setHeight(int hght){ height = hght; }
    
    /* Pointers to class-wide images used by each cell */
    static ImageBuffer *brick;  // brick tile
    static ImageBuffer *grass;  // grass tile
    static ImageBuffer *bob;    // bob tile    
    
private:
    
    int color;  // Border color if tile is not NULL, whole tile otherwise
    int fillMode;    
    ImageBuffer *tile; // Tile points to an image
    
    /* Class-wide (static) variables */
    static int width, height; // All cells have the same dimensions
};

#endif
