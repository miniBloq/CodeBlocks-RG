/**
 * Cell.cpp
 *
 * Implements a Cell class. 
 * A Cell is a rectangular area with a central tile and borders.
 *
 * @author jlk
 * @version 1.0 - August 2005
 */
#include <iostream>
#include <graphics.h>

#include "Cell.h"

// Initialise Cell class-wide variables
int Cell::width  = 20; // Pixel dimension
int Cell::height = 20; // Pixel dimension

int wnd = initwindow(30, 30); // A window must be open to create ImageBuffers
ImageBuffer *Cell::brick = new ImageBuffer( "img/brick.gif",
                                            Cell::width - 2, Cell::height - 2);
ImageBuffer *Cell::grass = new ImageBuffer( "img/grass.gif",
                                            Cell::width - 2, Cell::height - 2);
ImageBuffer *Cell::bob   = new ImageBuffer( "img/bob.gif",
                                            Cell::width - 2, Cell::height - 2);



// Constructor
Cell::Cell( int clr, int flMode, ImageBuffer *img)
: color(clr), fillMode(flMode), tile(img)
{}

// A function called by the grid setup() member function;
// allows the cell to set itself up depending on its grid location.
void Cell::setup(int x, int y)
{
    // Just a "magic" formula to set up something looking like a maze  
    if( ((y + 1) * x + 1) % 2 && ((y -1) * (x + 1) -1) % 3)
        setTile(grass);
    else
        setTile(brick);

}
    
// A function called by the grid read member function so
// the cell can read itself from stream
std::istream &Cell::read(std::istream &inputFile)
{
    // do the reading
    
    // return the stream
    return inputFile;
}   
    

// Draw the cell at given position (color, and tile if there is one)
void Cell::draw(int leftX, int topY, int drawMode)
{
    // draw rectangle of cell colour and fill mode
    struct fillsettingstype entryFill;
    getfillsettings( &entryFill ); // Store entry fill info to restore later
    setfillstyle(fillMode, color);
    /* Set vertices of our polygon array (rectangle) */
    int poly[8];
    poly[0] = leftX; poly[1] = topY;
    poly[2] = leftX + width; poly[3] = topY;
    poly[4] = leftX + width; poly[5] = topY + height;
    poly[6] = leftX; poly[7] = topY + height;
    // Draw rectangle
    fillpoly(4, poly);
    // restore original fill settings
    setfillstyle(entryFill.pattern, entryFill.color);
    
    // If tile is defined, draw it
    if(tile)
    {        
        // Attempt to centre the tile in the cell 
        int x = leftX + (Cell::width  - tile->getWidth() )  / 2;
        int y = topY  + (Cell::height - tile->getHeight() ) / 2;
        tile->putImage(x, y, drawMode);
    }
}

