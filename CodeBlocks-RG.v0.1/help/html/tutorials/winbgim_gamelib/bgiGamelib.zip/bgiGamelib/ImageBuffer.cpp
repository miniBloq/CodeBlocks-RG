/*
 * Class ImageBuffer manages the storage of an image in memory.
 * Provides: 
 *  Loading the image from file (BMP, GIF, JPG, ICO, EMF or WMF format).
 *  Drawing the image to screen.
 * 
 * @author  jlk
 * @version 1.0 12/08/05
 */
#include <graphics.h>

#include "ImageBuffer.h"

// Construct an image buffer from file
ImageBuffer::ImageBuffer(const char *filename, int wdth, int hght)
{
    // Size of image to load
    int size = imagesize(0, 0, wdth, hght);
    
    if(size <= 0) // If image is too big, set buffer to NULL
    {
        width = 0;
        height = 0;
        buffer = 0; 
    }
    else
    {
        width = wdth;
        height = hght;
    
        // reserve memory for the copy and the buffer
        char * current = (char *)malloc(size);
        buffer = (char *)malloc(size);
        
        // Store current screen area so as to restore later
        getimage(0, 0, wdth, hght, current);
        
        // Overwrite that area with the picture read from file
        swapbuffers();
        readimagefile(filename, 0, 0, wdth, hght);
        
        // Read the data to memory
        getimage(0, 0, wdth, hght, buffer);
        swapbuffers();
        
        // Restore the original screen
        putimage(0, 0, current, COPY_PUT);
        
        delete current;
    }
} 
    
// Construct an image buffer from part of the screen.
ImageBuffer::ImageBuffer(int leftX, int topY, int wdth, int hght)
{
    width = wdth;
    height = hght;
    
    // Size of image to load
    int size = imagesize(leftX, topY, wdth, hght);
    
    if(size <= 0) // If image is too big set buffer to NULL
    {
        width = 0;
        height = 0;
        buffer = 0; 
    }
    else
    {
        // reserve memory for the buffer
        buffer = (char *)malloc(size);
        // Read the data to memory
        getimage(0, 0, wdth, hght, buffer);
    }
}

// Draw image to active page
void ImageBuffer::putImage(int leftX, int topY, int op)
{
    if(buffer) // Don't bother if buffer is not loaded
        putimage(leftX, topY, buffer, op);
}

        

