/**
 * Program gridTest
 * Demonstrates drawing a 2D grid with WinBGIm and how to move characters
 * smoothly along the grid.
 * 
 * @author  jlk
 * @version 1.0 31/08/05
 */
#include <vector>
#include <graphics.h>

#include "ImageBuffer.h"
#include "Grid.h"

// Application constants
static const int CELL_ROWS  = 10;  // number of rows in grid
static const int CELL_COLS  = 10;  // number of columns in grid
static const int WIN_WIDTH  = 300; // Window width
static const int WIN_HEIGHT = 360; // Window height
static const int WIN_LEFT_X = 150; // window left X coordinate
static const int WIN_TOP_Y  = 150; // window top Y coordinate
static const int PAUSE      = 60;  // Milliseconds between animation frames

// Function Prototypes
void moveBob(Grid &grid);
int  startWindow(const char * const winTitle);

/* ---------------------------------------------------------- */
int main( )
{
    Cell aBob; // a cell with bob tile (The character to move on the grid)
    aBob.setTile(Cell::bob); // Place adequate iamge onto the cell

    // Open up the window
    startWindow("WinBGIm Grid Demo");
    
    // Create grid object
    Grid grid(CELL_ROWS, CELL_COLS); 
    
    grid.setCellData();  // Setup each cell on grid 
    
    // Locate and draw the grid
    int gridX = (WIN_WIDTH - grid.getWidth()) / 2;
    int gridY = gridX;
    grid.draw(gridX, gridY);
    
    // Print prompt near bottom of window
    int textX = getmaxx() / 2 - 50;
    int textY = getmaxy() - 80;
    outtextxy(textX, textY, "...any key to exit");
    
    // Now show some animation    
    while(!kbhit())
    {
        moveBob(grid);
        delay(PAUSE);
    }
}

/**
 * Move a character (Bob) along the grid.
 * 1- The tile containing Bob is erased from its current grid location by
 *    asking the grid to overwrite this location with a "grass" tile.
 * 2- The next location of Bob is computed and the grid draws the Bob cell
 *    at the new location.
 * The drawCell() member function is used for the drawing. drawCell() uses
 * double buffering to ensure smooth animation at any speed.
 *
 * @param grid reference to the Grid object.
 */
void moveBob(Grid &grid)
{
    // A Cell with bob tile (created once, the 1st time the function is called).
    static Cell aBob(BLACK, SOLID_FILL, Cell::bob);
    
    static int bobX = CELL_COLS - 1; // startup grid location
    static int bobY = 2;
    
    // Draw original grid cell
    grid.drawCell(grid.gridCell(bobX, bobY), bobX, bobY);
    // Move bob location then draw
    bobX = ++bobX % CELL_COLS;
    grid.drawCell(aBob, bobX, bobY);
}

/*
 * Place window on screen, ready to start
 *
 * @param  winTitle  The window heading
 * @return the window handle
 */
int startWindow(const char *winTitle)
{
    // reach into the internals of WinBGIm
    extern std::vector<HWND> BGI__WindowTable;  // WindowThread.cpp

    // Close window that was open to initialise the images
    closegraph();
	// Initialise application window size, title and location
    int winIndex = initwindow(  WIN_WIDTH, WIN_HEIGHT, winTitle,
                                WIN_LEFT_X, WIN_TOP_Y);
    if (winIndex  == -1)
        exit(1);
        
    // Force window to the foreground (obtain handle from WinBGIm internals)
    SetForegroundWindow(BGI__WindowTable[winIndex]);
    
    // Set double buffering to get smooth animation
    setactivepage(0);  
    setvisualpage(1);
    
    return winIndex;
}
