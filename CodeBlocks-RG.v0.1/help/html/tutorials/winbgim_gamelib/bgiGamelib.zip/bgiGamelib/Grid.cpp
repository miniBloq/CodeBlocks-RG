/**
 * Grid.cpp
 *
 * Implements a Grid class
 * Demonstrates animation with WinBGIm
 *
 * @author jlk
 * @version 1.0 - August 2005
 * @licence Public Domain
 */

#include "BGI_util.h" 
#include "Grid.h"


/**
 * Grid constructor
 *
 * @param numCellsX  int, number of cells in X dimension 
 * @param numCellsY  int, number of cells in X dimension 
 */
Grid::Grid(int numCellsX, int numCellsY)
: rowNum(numCellsY), colNum(numCellsX)
{    
    // Allocate memory for the 2D array of cells
    cell = new Cell*[rowNum]; // create the array of rows
    // Now create the cells in each row
    for(int count = 0; count < rowNum; count++)
        cell[count] = new Cell[colNum];
    
    // Now setup grid data 
    setCellData();
}

// Destructor. Releases all Grid object memory allocated dynamically
Grid::~Grid()
{
    if(cell != 0)
    {
        for(int count = 0; count < rowNum; count++)
            delete [] cell[count]; // Delete each row
        // now delete array of rows
        delete [] cell;
    }
}

/* Sets the data for each cell in grid
 * This is done simply here by passing the cell its position on the grid,
 * But it could be done by asking the cell to read itself from file using
 * its read() member function, etc..
 */
void Grid::setCellData()
{    
    for( int row = 0; row < rowNum; row++)
    {
        for(int col = 0; col < colNum; col++)
        {
            cell[row][col].setup(row, col);            
        }
    }
}

/* Read the data from stream for each cell in grid
 * This is done simply here by passing the stream to the cell
 */
std::istream &Grid::read(std::istream &input) const
{    
    for( int row = 0; row < rowNum; row++)
    {
        for(int col = 0; col < colNum; col++)
        {
            cell[row][col].read(input);            
        }
    }
    
    return input;
}

// Ask each cell to draw itself at a given position
void Grid::draw(int leftX, int topY)
{
    for( int row = 0; row < rowNum; row++)
    {
        for(int col = 0; col < colNum; col++)
        {
            // Calculate cell position
            int x = leftX + col * Cell::getWidth();
            int y = topY  + row * Cell::getHeight();
            // draw
            cell[row][col].draw(x, y);
        }
    }
    synchronize(); // Double buffering
    xOffset = leftX;
    yOffset = topY;
}

// Obtain reference to a grid cell
Cell & Grid::gridCell(int colIndex, int rowIndex)
{
     return cell[rowIndex][colIndex];
}
    
// Draw a cell at a particular location in grid
void Grid::drawCell(Cell &c, int colIndex, int rowIndex)
{   
    // Calculate cell position
    int x = xOffset + colIndex * Cell::getWidth();
    int y = yOffset + rowIndex * Cell::getHeight();

    c.draw(x, y);
 // Never forget double-buffering to avoid flicker
    synchronize(); // Never forget double-buffering to avoid flicker
}

