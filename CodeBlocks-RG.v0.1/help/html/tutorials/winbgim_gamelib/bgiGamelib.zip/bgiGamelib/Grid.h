/**
 * Grid.h
 *
 * Declares a Grid class. A Grid is a 2D array of cells
 *
 * @author jlk
 * @version 1.0 - August 2005
 */
 
#ifndef GRID_H
#define GRID_H

#include <string>
#include "Cell.h"

class Grid
{    
public:
    /**
     * Construct a Grid object
     *
     * @param numCellsX -int, number of cells in grid along the X axis 
     * @param numCellsY -int, number of cells in grid along the Y axis 
     */
    Grid(int numCellsX, int numCellsY);
    
    /**
     * Destructor (frees cell array memory allocated dynamically)
     */
    ~Grid();

    /**
     * Setup cell data for each cell on the grid
     */
    void setCellData();

    /**
     * Setup grid offset (position of Grid top-left corner in window)
     *
     * @param x -int offset (in pixels) from the left edge of window
     * @param y -int offset (in pixels) from the top edge of window
     */
    inline void setOffset(int x, int y){xOffset = x; yOffset = y;}

    /**
     * Obtain reference to a grid cell given its position in array
     *
     * @param colIndex -int, the column index in array
     * @param rowIndex -int, the row index in array
     *
     * @return the cell reference
     */
    Cell & gridCell(int colIndex, int rowIndex);
    
    /**
     * Draw a cell at a particular location
     *
     * @param c -int, Cell reference. The cell to draw
     * @param colIndex -int, the column index in array
     * @param rowIndex -int, the row index in array
     */
    void drawCell(Cell &c, int colIndex, int rowIndex);
        
    /**
     * Read the data from stream for each cell in grid
     *
     * @param input -istream reference, An open input stream to read from
     *
     * @return the input stream reference
     */
    std::istream &read(std::istream &input) const;
    
    /**
     * Draw grid at position given in window
     *
     * @param leftX -int, x coordinate of the left edge of the grid
     * @param topY  -int, y coordinate of the top edge of the grid
     */
    void draw(int leftX = 0, int topY = 0); 
    
    /**
      * @return -the grid width in pixels
      */
    inline int getWidth(){return colNum * Cell::getWidth();}

    /**
     * @return -the grid height in pixels
     */
    inline int getHeight(){return rowNum * Cell::getHeight();}
    
private:
    // Grid dimensions (in numbers of cells)    
    int rowNum;   // number of cells in y dimension
    int colNum;   // number of cells in x dimension
    
    int xOffset, yOffset; // Grid location in window (top-left corner)
    
    // grid images
    static ImageBuffer *brick;
    static ImageBuffer *grass;
    static ImageBuffer *bob;

    // A grid is a 2D array of cells created at runtime 
    Cell **cell;  
};

#endif

