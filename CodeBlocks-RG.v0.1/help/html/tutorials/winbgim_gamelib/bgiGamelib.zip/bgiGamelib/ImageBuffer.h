/**
 * Class ImageBuffer manages the storage of an image in memory.
 * Provides: 
 *  Loading the image from file (BMP, GIF, JPG, ICO, EMF or WMF format).
 *  Drawing the image to screen.
 * 
 * @author  jlk
 * @version 1.0 12/08/05
 */

#ifndef IMAGE_BUFFER_H
#define IMAGE_BUFFER_H

class ImageBuffer
{
public:
    // Default constructor
    ImageBuffer(): buffer(0){} 
    
    /** Construct an image buffer when given the file name to load.
     *  Reads a BMP, GIF, JPG, ICO, EMF or WMF image file
     * @param filename Path of file to load image from
     * @param width  number of pixels of image width to read
     * @param height number of pixels of image height to read
     */
    ImageBuffer(const char *filename, int width, int height);
    
    /** Construct an image buffer from part of the screen.
     *  
     * @param leftX x coordinate of top left corner of image
     * @param topY  y coordinate of top left corner of image
     * @param width  number of pixels of image width to read
     * @param height number of pixels of image height to read
     */
    ImageBuffer(int leftX, int topY, int width, int height);
    
    // Destructor
    inline ~ImageBuffer(){delete(buffer);};
    
    /**
     * Draw image to active page
     *
     * @param leftX x coordinate of top left corner of image
     * @param topY  y coordinate of top left corner of image
     */
    void putImage(int leftX = 0, int topY = 0, int op = COPY_PUT);

    /**
     * Obtain image width in pixels
     *
     * @return int, the width
     */
    inline int getWidth(){return width;}

    /**
     * Obtain image height in pixels
     *
     * @return int, the height
     */
    inline int getHeight(){return height;}

private:
    int width;
    int height;
    char *buffer; // Store picture data
};
    
#endif
