/* File: kplot.c
 *
 *	 	Commented examples of graph drawing with
 *		the koolplot library.
 *
 * Date:	January 2005
 * 
 * This file is in the public domain and can be used without any
 * restriction.
 */

#include "koolplot.h"

/* Function prototypes. They give the form (signature) of functions
 * that can be used in the code below in main().
 */
double sinc(double x);
double tanLessThan(double x, double max);


int main()
{
	/* give range of X axis, then define Y as x^2 + 3x + 3 */
	Plotdata	x(-5, 2),  
				y = x*x + 3*x + 3;

	/* Plot the graph */
	plot(x, y); 


	/**********************************************************/
	/* Points may be entered one at a time into the axes data */
	/* .. a "point-by-point" data entry method.               */

 	/* Erase previous data in axes X and Y so they can be re-used.*/	
	clear(x);
	clear(y); 
	
	/* 
	 * Enter each curve point as a coordinate pair using the Plotdata 
	 * insertion operator "<<" ( or use the "point" function instead).
	 */
	for (int i = -180 ; i <= 180; i++)
	{
		double y_value = i / 180.0 + cos(M_PI * i / 180);
		x << i;
		y << y_value;
		
		/* "<<" inserts a new value into the plot data.
		 * You could instead use the point function, with
		 * point(x, y, i, y_value); if you prefer.
		 */
	}
	
	/* Graph drawn in magenta colour (Each data point is joined to
	 * the preceding and following points, forming the curve.). 
	 */
	plot(x, y, MAGENTA);
		

	/**********************************************/	
	/* Plot function y = sin(x) between 0 and 360 */
	x = Plotdata(-0, 360); 
	y = sin(x * M_PI / 180);
	/* Give the function name to be printed as the window label */
	plot(x, y, LIGHTRED, "sin(x)");


	/*****************************************************************/
	/* Plot user-defined unary function f(x) = sinc between -6 and 6 */
	x 	 = Plotdata(-6, 6);
	f(x) = sinc;  	  /* sinc is defined at the bottom of this file. */
	plot(x, f(x), "sinc(x)");
	

	/*****************************************************************/      
	/* Plot user-defined binary function y = tanLessThan(x, max)     */
	/* Read tanLessThan code to see how values > max are not plotted */
	x = Plotdata(-270, 270); 
	f2(x) = tanLessThan;
	/* Do not plot y values greater than 20 */
	plot(x, f2(x, 20), "tan(x)", RED);


	/*********************************************************************/
	/* Plot 2 functions on same graph (could be any number of functions) */
	/* Define Y as two functions */
	clear(x); /* Re-use old X, but change its range to -75..245 degrees  */
	x << Plotdata(-80, 255);
	y = f2(x, 3); /* First function */
	
	breakplot(x, y);    /* Break the plot between functions */
	/* You could also use x << NOPLOT; y << NOPLOT; instead.*/
	
	/* Define second function (2cos(2x)) on same range "point-by-point"  */
	for(int i = -80; i <= 255; i++)
	{
		x << i;
		y << 2 * cos(2 * M_PI * i / 180);
	}

	plot(x, y, "tan(x) and 2cos(2x)", CYAN);
	

	/***********************************************************
	 * You can also use the << operator to insert data at the end
	 * of already entered plot data in order to draw 2 or more
	 * functions.
	 *
	 * Use NOPLOT to separate different function data in both X 
	 * and Y, but be careful of the order of insertion! Each NOPLOT
	 * in X must correspond to a NOPLOT in Y.
	 *
	 * Koolplot does not plot NOPLOT values.
	 */	   
	x = Plotdata(-315, 45);
	y = sin(x * M_PI / 180) << NOPLOT << cos(x * M_PI / 180);
	
	/* Must be inserted into X, below, only after defining Y */
	x << NOPLOT << Plotdata(-315, 45);
	
	plot(x, y, " sin(x) and cos(x)", MAGENTA);

	/*************************************************/


	return 0;
}


/*
 * Sinc: user-defined unary function y = sin(PI + x) / (PI * x),
 * except for x = 0 when y = 1.
 * Sinc is an important function in science and engineering.
 */
double sinc(double x)
{
	if (fabs(x) < 0.0001)
		return 1.0;
	else 
		return sin(M_PI * x) / (M_PI * x);
}


/*
 * tanLessThan: User-defined binary function.
 *
 * Returns tan(x) values below max.
 *
 * - Any value of tan(x) above "max" is returned as NOPLOT (a special 
 *   value known as NaN (not a number) in C).
 * - This is done because tan x grows very fast towards infinity (or minus
 *   infinity) at some values. Of course infinity cannot be plotted!
 * - Koolplot never attempts to draw NOPLOT values.
 */
double tanLessThan(double x, double max)
{	 
	double y = tan(x * M_PI / 180);
	
	if(fabs(y) > max)
		return NOPLOT; // This point will not be on the graph
	else
		return y;
}
